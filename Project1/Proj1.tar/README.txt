
Marcos Gomez

server.c - used to create the server
client.c - used to create the client

use Makefile to compile both of these.

